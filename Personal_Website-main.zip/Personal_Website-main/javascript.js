//Future development needed
//Let's alert the user that they should have a great day on each page


//Step 1. Add css element to index or home page
//Step 2. ... to about page
//Step 3. ... to portfolio page


//step1
const positiveprompt = "Have a great day!"




alert(positiveprompt + " Please hit OK to visit page~")

